-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Czas generowania: 10 Paź 2023, 12:52
-- Wersja serwera: 10.4.24-MariaDB
-- Wersja PHP: 8.0.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Baza danych: `lotnisko`
--

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `backupiodtwarzanieawaryjne`
--

CREATE TABLE `backupiodtwarzanieawaryjne` (
  `ID` int(11) NOT NULL,
  `KopieZapasoweDanych` text DEFAULT NULL,
  `InformacjeOKopiachZapasowych` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Zrzut danych tabeli `backupiodtwarzanieawaryjne`
--

INSERT INTO `backupiodtwarzanieawaryjne` (`ID`, `KopieZapasoweDanych`, `InformacjeOKopiachZapasowych`) VALUES
(1, 'Regularne kopie zapasowe wykonywane codziennie o godzinie 01:00', NULL),
(2, 'Dane archiwizowane w lokalnych centrach danych i w chmurze', NULL),
(3, 'Przechowywanie kopii zapasowych przez okres 90 dni', NULL),
(4, 'Odtwarzanie awaryjne testowane co kwartał', NULL),
(5, 'Protokół awaryjnego odtwarzania w razie utraty danych', NULL);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `danebagażu`
--

CREATE TABLE `danebagażu` (
  `ID` int(11) NOT NULL,
  `NumerBiletu` varchar(20) DEFAULT NULL,
  `NumerLotu` varchar(20) DEFAULT NULL,
  `WagaBagażu` decimal(5,2) DEFAULT NULL,
  `StatusBagażu` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Zrzut danych tabeli `danebagażu`
--

INSERT INTO `danebagażu` (`ID`, `NumerBiletu`, `NumerLotu`, `WagaBagażu`, `StatusBagażu`) VALUES
(1, 'B12345', 'LO123', '20.50', 'odebrany'),
(2, 'B23456', 'UA456', '18.20', 'odebrany'),
(3, 'B34567', 'LH789', '15.00', 'odebrany'),
(4, 'B45678', 'TK012', '22.10', 'odebrany'),
(5, 'B56789', 'AF345', '16.80', 'odebrany'),
(6, 'B67890', 'BA678', '19.50', 'odebrany'),
(7, 'B78901', 'DL901', '21.30', 'odebrany'),
(8, 'B89012', 'SQ234', '14.70', 'odebrany'),
(9, 'B90123', 'EK567', '23.00', 'odebrany'),
(10, 'B01234', 'CX890', '17.60', 'odebrany');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `danebezpieczeństwa`
--

CREATE TABLE `danebezpieczeństwa` (
  `ID` int(11) NOT NULL,
  `DaneNiebezpieczne` text DEFAULT NULL,
  `InformacjeOKontroliBezpieczeństwa` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Zrzut danych tabeli `danebezpieczeństwa`
--

INSERT INTO `danebezpieczeństwa` (`ID`, `DaneNiebezpieczne`, `InformacjeOKontroliBezpieczeństwa`) VALUES
(1, 'Jan Kowalski', 'Podmiot na liście No Fly'),
(2, 'Anna Nowak', 'Kontrola bezpieczeństwa przeszła pomyślnie'),
(3, 'Michał Wiśniewski', 'Podmiot na liście No Fly'),
(4, 'Ewa Zawadzka', 'Kontrola bezpieczeństwa przeszła pomyślnie'),
(5, 'Adam Kaczmarek', 'Kontrola bezpieczeństwa przeszła pomyślnie'),
(6, 'Maria Lewandowska', 'Kontrola bezpieczeństwa przeszła pomyślnie'),
(7, 'Piotr Adamczyk', 'Kontrola bezpieczeństwa przeszła pomyślnie'),
(8, 'Monika Czajka', 'Podmiot na liście No Fly'),
(9, 'Kamil Szymczak', 'Kontrola bezpieczeństwa przeszła pomyślnie'),
(10, 'Alicja Duda', 'Kontrola bezpieczeństwa przeszła pomyślnie');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `danelotów`
--

CREATE TABLE `danelotów` (
  `ID` int(11) NOT NULL,
  `NumerLotu` varchar(20) DEFAULT NULL,
  `DataOdlotu` datetime DEFAULT NULL,
  `DataPrzylotu` datetime DEFAULT NULL,
  `MiejsceStartu` varchar(255) DEFAULT NULL,
  `MiejsceDocelowe` varchar(255) DEFAULT NULL,
  `NumerBramkiOdlotowej` varchar(10) DEFAULT NULL,
  `NumerMiejscaNaPokładzie` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Zrzut danych tabeli `danelotów`
--

INSERT INTO `danelotów` (`ID`, `NumerLotu`, `DataOdlotu`, `DataPrzylotu`, `MiejsceStartu`, `MiejsceDocelowe`, `NumerBramkiOdlotowej`, `NumerMiejscaNaPokładzie`) VALUES
(1, 'LO123', '2023-10-01 08:00:00', '2023-10-01 10:30:00', 'Warszawa', 'Nowy Jork', 'Gate 1', 10),
(2, 'UA456', '2023-10-02 15:30:00', '2023-10-02 18:45:00', 'Los Angeles', 'Chicago', 'Gate 2', 15),
(3, 'LH789', '2023-10-03 11:45:00', '2023-10-03 14:20:00', 'Frankfurt', 'London', 'Gate 3', 20),
(4, 'TK012', '2023-10-04 09:15:00', '2023-10-04 11:40:00', 'Istanbul', 'Dubai', 'Gate 4', 12),
(5, 'AF345', '2023-10-05 14:30:00', '2023-10-05 17:10:00', 'Paris', 'Barcelona', 'Gate 5', 18),
(6, 'BA678', '2023-10-06 07:20:00', '2023-10-06 09:50:00', 'London', 'Rome', 'Gate 6', 8),
(7, 'DL901', '2023-10-07 10:00:00', '2023-10-07 12:30:00', 'New York', 'Miami', 'Gate 7', 14),
(8, 'SQ234', '2023-10-08 13:45:00', '2023-10-08 16:10:00', 'Singapore', 'Tokyo', 'Gate 8', 22),
(9, 'EK567', '2023-10-09 18:30:00', '2023-10-09 21:15:00', 'Dubai', 'Sydney', 'Gate 9', 24),
(10, 'CX890', '2023-10-10 05:55:00', '2023-10-10 07:40:00', 'Hong Kong', 'Seoul', 'Gate 10', 16);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `danepasażerów`
--

CREATE TABLE `danepasażerów` (
  `ID` int(11) NOT NULL,
  `ImięNazwisko` varchar(255) DEFAULT NULL,
  `DataUrodzenia` date DEFAULT NULL,
  `Płeć` varchar(10) DEFAULT NULL,
  `NumerDokumentu` varchar(20) DEFAULT NULL,
  `KrajPochodzenia` varchar(255) DEFAULT NULL,
  `InformacjeKontaktowe` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Zrzut danych tabeli `danepasażerów`
--

INSERT INTO `danepasażerów` (`ID`, `ImięNazwisko`, `DataUrodzenia`, `Płeć`, `NumerDokumentu`, `KrajPochodzenia`, `InformacjeKontaktowe`) VALUES
(1, 'Jan Kowalski', '1990-05-15', 'Mężczyzna', 'ABC123', 'Polska', 'ul. Testowa 1, 12345 Warszawa, +48 123 456 789, jan.kowalski@example.com'),
(2, 'Anna Nowak', '1985-08-20', 'Kobieta', 'DEF456', 'USA', '123 Main St, New York, NY 10001, +1 987 654 321, anna.nowak@example.com'),
(3, 'Michał Wiśniewski', '2000-03-10', 'Mężczyzna', 'GHI789', 'Polska', 'ul. Inna 5, 54321 Kraków, +48 987 654 321, michal.wisniewski@example.com'),
(4, 'Ewa Zawadzka', '1992-12-25', 'Kobieta', 'JKL012', 'Niemcy', 'Am Platz 7, 98765 Berlin, +49 123 456 789, ewa.zawadzka@example.com'),
(5, 'Adam Kaczmarek', '1978-07-03', 'Mężczyzna', 'MNO345', 'Polska', 'ul. Testowa 2, 54321 Poznań, +48 555 555 555, adam.kaczmarek@example.com'),
(6, 'Maria Lewandowska', '1982-04-18', 'Kobieta', 'PQR678', 'Polska', 'ul. Przykładowa 3, 67890 Gdańsk, +48 777 777 777, maria.lewandowska@example.com'),
(7, 'Piotr Adamczyk', '1995-09-28', 'Mężczyzna', 'STU901', 'Polska', 'ul. Inna 6, 76543 Wrocław, +48 999 999 999, piotr.adamczyk@example.com'),
(8, 'Monika Czajka', '1989-02-14', 'Kobieta', 'VWX234', 'Polska', 'ul. Przykładowa 4, 43210 Łódź, +48 666 666 666, monika.czajka@example.com'),
(9, 'Kamil Szymczak', '1975-11-08', 'Mężczyzna', 'YZA567', 'Polska', 'ul. Testowa 5, 54321 Katowice, +48 111 111 111, kamil.szymczak@example.com'),
(10, 'Alicja Duda', '2003-06-30', 'Kobieta', 'BCD890', 'Polska', 'ul. Inna 7, 98765 Szczecin, +48 222 222 222, alicja.duda@example.com');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `danepersonelulotniska`
--

CREATE TABLE `danepersonelulotniska` (
  `ID` int(11) NOT NULL,
  `ImięNazwisko` varchar(255) DEFAULT NULL,
  `StanowiskoPracy` varchar(255) DEFAULT NULL,
  `NumerIdentyfikacyjnyPracownika` varchar(20) DEFAULT NULL,
  `GodzinyPracy` varchar(50) DEFAULT NULL,
  `LotniskoLubLot` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Zrzut danych tabeli `danepersonelulotniska`
--

INSERT INTO `danepersonelulotniska` (`ID`, `ImięNazwisko`, `StanowiskoPracy`, `NumerIdentyfikacyjnyPracownika`, `GodzinyPracy`, `LotniskoLubLot`) VALUES
(1, 'Janina Kowalska', 'Pracownik Obsługi Pasażerów', 'EMP001', 'Pon-Pt 08:00-16:00', 'Lotnisko Chopina, Warszawa'),
(2, 'Andrzej Nowak', 'Personel Bodźca Bezpieczeństwa', 'EMP002', 'Pon-Nd 24/7', 'Lotnisko O, Hare, Chicago'),
(3, 'Karolina Wiśniewska', 'Personel Obsługi Klienta', 'EMP003', 'Pon-Nd 09:00-18:00', 'Lotnisko Schiphol, Amsterdam'),
(4, 'Marek Zawadzki', 'Personel Obsługi Bagażem', 'EMP004', 'Pon-Nd 07:00-15:00', 'Lot EK567, Dubai-Sydney'),
(5, 'Grzegorz Kaczmarek', 'Personel Obsługi Technicznej', 'EMP005', 'Pon-Pt 08:00-17:00', 'Warsztat Lotniczy, Poznań'),
(6, 'Jadwiga Lewandowska', 'Personel Sprawdzający Bilety', 'EMP006', 'Pon-Nd 09:00-20:00', 'Lotnisko Gatwick, Londyn'),
(7, 'Tomasz Adamczyk', 'Personel Kontroli Lotów', 'EMP007', 'Pon-Pt 07:30-16:30', 'Kierownictwo Ruchu Lotniczego, Warszawa'),
(8, 'Magdalena Czajka', 'Personel Techniczny Samolotów', 'EMP008', 'Pon-Nd 24/7', 'Hangar Techniczny, Kraków'),
(9, 'Wojciech Szymczak', 'Personel Logistyki Lotów', 'EMP009', 'Pon-Pt 08:00-17:00', 'Magazyn Lotniczy, Gdańsk'),
(10, 'Kinga Duda', 'Personel Zarządzania Ruchem', 'EMP010', 'Pon-Nd 24/7', 'Centrum Operacyjne, Warszawa');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `daneprzesyłekicargo`
--

CREATE TABLE `daneprzesyłekicargo` (
  `ID` int(11) NOT NULL,
  `NumerPrzesyłki` varchar(20) DEFAULT NULL,
  `MasaPrzesyłki` decimal(5,2) DEFAULT NULL,
  `AdresDostawy` varchar(255) DEFAULT NULL,
  `NumerLotuCargo` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Zrzut danych tabeli `daneprzesyłekicargo`
--

INSERT INTO `daneprzesyłekicargo` (`ID`, `NumerPrzesyłki`, `MasaPrzesyłki`, `AdresDostawy`, `NumerLotuCargo`) VALUES
(1, 'CARGO001', '500.00', '123 Cargo St, Chicago, IL', 'UA456'),
(2, 'CARGO002', '300.50', '456 Cargo Ave, Los Angeles, CA', 'DL901'),
(3, 'CARGO003', '700.20', '789 Cargo Rd, Frankfurt', 'LH789'),
(4, 'CARGO004', '400.80', '101 Cargo Blvd, Dubai', 'EK567'),
(5, 'CARGO005', '600.10', '222 Cargo Dr, Sydney', 'SQ234'),
(6, 'CARGO006', '250.00', '333 Cargo Lane, London', 'BA678'),
(7, 'CARGO007', '350.70', '444 Cargo Pl, Tokyo', 'SQ234'),
(8, 'CARGO008', '450.20', '555 Cargo Ct, Hong Kong', 'CX890'),
(9, 'CARGO009', '550.50', '666 Cargo Rd, Seoul', 'CX890'),
(10, 'CARGO010', '200.00', '777 Cargo St, New York, NY', 'UA456');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `danesamolotów`
--

CREATE TABLE `danesamolotów` (
  `ID` int(11) NOT NULL,
  `NumerRejestracyjnySamolotu` varchar(20) DEFAULT NULL,
  `ModelSamolotu` varchar(255) DEFAULT NULL,
  `IlośćMiejscNaPokładzie` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Zrzut danych tabeli `danesamolotów`
--

INSERT INTO `danesamolotów` (`ID`, `NumerRejestracyjnySamolotu`, `ModelSamolotu`, `IlośćMiejscNaPokładzie`) VALUES
(1, 'SP-ABC', 'Boeing 737', 150),
(2, 'N12345', 'Airbus A320', 180),
(3, 'D-A123', 'Boeing 777', 300),
(4, 'TC-XYZ', 'Airbus A380', 500),
(5, 'G-7890', 'Embraer E190', 100),
(6, 'F-GHIJ', 'Airbus A350', 250),
(7, 'JA-456', 'Boeing 747', 400),
(8, 'HL-KLM', 'Airbus A330', 280),
(9, 'VH-QWE', 'Boeing 787', 240),
(10, 'B-7890', 'Embraer E175', 90);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `danestatystyczne`
--

CREATE TABLE `danestatystyczne` (
  `ID` int(11) NOT NULL,
  `RaportyStatystyki` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Zrzut danych tabeli `danestatystyczne`
--

INSERT INTO `danestatystyczne` (`ID`, `RaportyStatystyki`) VALUES
(1, 'Liczba pasażerów: 1500, Opóźnień lotów: 10, Odwołanych lotów: 2'),
(2, 'Liczba pasażerów: 1800, Opóźnień lotów: 5, Odwołanych lotów: 1'),
(3, 'Liczba pasażerów: 2200, Opóźnień lotów: 8, Odwołanych lotów: 3'),
(4, 'Liczba pasażerów: 1300, Opóźnień lotów: 12, Odwołanych lotów: 4'),
(5, 'Liczba pasażerów: 1600, Opóźnień lotów: 6, Odwołanych lotów: 0'),
(6, 'Liczba pasażerów: 1900, Opóźnień lotów: 9, Odwołanych lotów: 2'),
(7, 'Liczba pasażerów: 2100, Opóźnień lotów: 7, Odwołanych lotów: 1'),
(8, 'Liczba pasażerów: 2500, Opóźnień lotów: 11, Odwołanych lotów: 2'),
(9, 'Liczba pasażerów: 2800, Opóźnień lotów: 14, Odwołanych lotów: 3'),
(10, 'Liczba pasażerów: 3000, Opóźnień lotów: 10, Odwołanych lotów: 1');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `historialotów`
--

CREATE TABLE `historialotów` (
  `ID` int(11) NOT NULL,
  `OperacjeLotnicze` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Zrzut danych tabeli `historialotów`
--

INSERT INTO `historialotów` (`ID`, `OperacjeLotnicze`) VALUES
(1, 'Lot LO123 z Warszawy do Nowego Jorku odbędzie się 2023-10-01 o 08:00'),
(2, 'Lot UA456 z Los Angeles do Chicago odbędzie się 2023-10-02 o 15:30'),
(3, 'Lot LH789 z Frankfurtu do Londynu odbędzie się 2023-10-03 o 11:45'),
(4, 'Lot TK012 z Stambułu do Dubaju odbędzie się 2023-10-04 o 09:15'),
(5, 'Lot AF345 z Paryża do Barcelony odbędzie się 2023-10-05 o 14:30'),
(6, 'Lot BA678 z Londynu do Rzymu odbędzie się 2023-10-06 o 07:20'),
(7, 'Lot DL901 z Nowego Jorku do Miami odbędzie się 2023-10-07 o 10:00'),
(8, 'Lot SQ234 z Singapuru do Tokio odbędzie się 2023-10-08 o 13:45'),
(9, 'Lot EK567 z Dubaju do Sydney odbędzie się 2023-10-09 o 18:30'),
(10, 'Lot CX890 z Hong Kongu do Seulu odbędzie się 2023-10-10 o 05:55');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `systembagażowy`
--

CREATE TABLE `systembagażowy` (
  `ID` int(11) NOT NULL,
  `ŚledzenieBagażuPasażerów` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Zrzut danych tabeli `systembagażowy`
--

INSERT INTO `systembagażowy` (`ID`, `ŚledzenieBagażuPasażerów`) VALUES
(1, 'Bagaż pasażera o numerze biletu R12345 został załadowany na lot LO123'),
(2, 'Bagaż pasażera o numerze biletu R23456 został załadowany na lot UA456'),
(3, 'Bagaż pasażera o numerze biletu R34567 został załadowany na lot LH789'),
(4, 'Bagaż pasażera o numerze biletu R45678 został załadowany na lot TK012'),
(5, 'Bagaż pasażera o numerze biletu R56789 został załadowany na lot AF345'),
(6, 'Bagaż pasażera o numerze biletu R67890 został załadowany na lot BA678'),
(7, 'Bagaż pasażera o numerze biletu R78901 został załadowany na lot DL901'),
(8, 'Bagaż pasażera o numerze biletu R89012 został załadowany na lot SQ234'),
(9, 'Bagaż pasażera o numerze biletu R90123 został załadowany na lot EK567'),
(10, 'Bagaż pasażera o numerze biletu R01234 został załadowany na lot CX890');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `systemkontrolilotów`
--

CREATE TABLE `systemkontrolilotów` (
  `ID` int(11) NOT NULL,
  `MonitorowanieRuchuLotniczego` text DEFAULT NULL,
  `ZarządzanieTrasamiLotów` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Zrzut danych tabeli `systemkontrolilotów`
--

INSERT INTO `systemkontrolilotów` (`ID`, `MonitorowanieRuchuLotniczego`, `ZarządzanieTrasamiLotów`) VALUES
(1, 'Monitorowanie ruchu lotniczego w czasie rzeczywistym', 'Zarządzanie trasami lotów na podstawie dostępności tras'),
(2, 'System wykrywa opóźnienia w ruchu lotniczym', 'Automatyczne przekierowywanie lotów na alternatywne trasy'),
(3, 'Zintegrowane mapy z lotniskami i trasami lotów', 'Aktualizacja tras lotów na podstawie warunków atmosferycznych'),
(4, 'Powiadomienia o zmianach w planach lotów', 'Synchronizacja z systemem rezerwacji biletów'),
(5, 'Raporty o ruchu lotniczym', 'Optymalizacja tras lotów w czasie rzeczywistym');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `systemobsługiklienta`
--

CREATE TABLE `systemobsługiklienta` (
  `ID` int(11) NOT NULL,
  `ObsługaSkargIPytanPasażerów` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Zrzut danych tabeli `systemobsługiklienta`
--

INSERT INTO `systemobsługiklienta` (`ID`, `ObsługaSkargIPytanPasażerów`) VALUES
(1, 'Kontakt telefoniczny z obsługą klienta dostępny 24/7'),
(2, 'Obsługa klienta na lotnisku w punkcie informacyjnym'),
(3, 'System zgłaszania skarg i pytań online'),
(4, 'Szybkie rozpatrywanie skarg i pytań przez e-mail'),
(5, 'Personel obsługi klienta jest wielojęzyczny i pomocny');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `systemrezerwacji`
--

CREATE TABLE `systemrezerwacji` (
  `ID` int(11) NOT NULL,
  `RezerwacjeLotówOnline` text DEFAULT NULL,
  `PrzetwarzaniePłatnościBiletów` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Zrzut danych tabeli `systemrezerwacji`
--

INSERT INTO `systemrezerwacji` (`ID`, `RezerwacjeLotówOnline`, `PrzetwarzaniePłatnościBiletów`) VALUES
(1, 'System rezerwacji działa online', 'Płatności za bilety są przetwarzane przez system płatności online'),
(2, 'Klient może dokonać rezerwacji online', 'System obsługuje płatności kartą kredytową'),
(3, 'Zarezerwowane bilety są przesyłane na adres e-mail', 'Akceptowane są płatności za pośrednictwem PayPal'),
(4, 'Klienci mogą wybierać miejsca na pokładzie', 'System obsługuje płatności gotówką na lotnisku'),
(5, 'Rezerwacje można dokonywać przez aplikację mobilną', 'Płatności można dokonać przelewem bankowym'),
(6, 'Klienci mogą zmieniać daty lotów online', 'Akceptowane są płatności za pomocą kryptowalut'),
(7, 'Pasażerowie mogą dokonywać rezerwacji przez agencje podróży', 'System obsługuje płatności za pomocą bonów podarunkowych'),
(8, 'Zarezerwowane bilety są dostępne w panelu klienta', 'Płatności można dokonać za pomocą kuponów rabatowych'),
(9, 'System rezerwacji jest dostępny 24/7', 'Płatności są potwierdzane SMS-em'),
(10, 'Klienci mogą anulować rezerwacje online', 'Akceptowane są płatności za pomocą aplikacji mobilnej');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `zabezpieczeniaiuprawnienia`
--

CREATE TABLE `zabezpieczeniaiuprawnienia` (
  `ID` int(11) NOT NULL,
  `OchronaDanychOsobowych` text DEFAULT NULL,
  `UprawnieniaDostępuDoDanych` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Zrzut danych tabeli `zabezpieczeniaiuprawnienia`
--

INSERT INTO `zabezpieczeniaiuprawnienia` (`ID`, `OchronaDanychOsobowych`, `UprawnieniaDostępuDoDanych`) VALUES
(1, 'Stosowanie protokołów szyfrowania danych', 'Uprawnienia dostępu do danych w zależności od roli użytkownika'),
(2, 'Monitorowanie dostępu do danych i logowanie zdarzeń', 'Uprawnienia do modyfikacji tylko dla wybranych użytkowników'),
(3, 'Szkolenia dotyczące ochrony danych osobowych', 'Kontrola dostępu na poziomie rekordów i kolumn'),
(4, 'Zarządzanie hasłami i polityka bezpieczeństwa', 'Audyt dostępu do danych'),
(5, 'Dostęp do danych tylko w celach służbowych', 'Ustalanie poziomów dostępu w oparciu o potrzeby użytkowników');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `zarezerwowanebilety`
--

CREATE TABLE `zarezerwowanebilety` (
  `ID` int(11) NOT NULL,
  `NumerBiletu` varchar(20) DEFAULT NULL,
  `CenaBiletu` decimal(10,2) DEFAULT NULL,
  `KlasaBiletu` varchar(20) DEFAULT NULL,
  `StatusPłatności` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Zrzut danych tabeli `zarezerwowanebilety`
--

INSERT INTO `zarezerwowanebilety` (`ID`, `NumerBiletu`, `CenaBiletu`, `KlasaBiletu`, `StatusPłatności`) VALUES
(1, 'R12345', '450.00', 'ekonomiczna', 'opłacone'),
(2, 'R23456', '800.00', 'biznesowa', 'opłacone'),
(3, 'R34567', '1200.00', 'pierwsza klasa', 'opłacone'),
(4, 'R45678', '350.00', 'ekonomiczna', 'opłacone'),
(5, 'R56789', '700.00', 'biznesowa', 'nieopłacone'),
(6, 'R67890', '300.00', 'ekonomiczna', 'opłacone'),
(7, 'R78901', '900.00', 'biznesowa', 'nieopłacone'),
(8, 'R89012', '1100.00', 'pierwsza klasa', 'opłacone'),
(9, 'R90123', '400.00', 'ekonomiczna', 'opłacone'),
(10, 'R01234', '750.00', 'biznesowa', 'nieopłacone');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `zarządzaniezasobami`
--

CREATE TABLE `zarządzaniezasobami` (
  `ID` int(11) NOT NULL,
  `DostępneBramki` int(11) DEFAULT NULL,
  `StanPaliwa` decimal(10,2) DEFAULT NULL,
  `DostępneSlotyStartowe` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Zrzut danych tabeli `zarządzaniezasobami`
--

INSERT INTO `zarządzaniezasobami` (`ID`, `DostępneBramki`, `StanPaliwa`, `DostępneSlotyStartowe`) VALUES
(1, 15, '50000.00', 30),
(2, 20, '75000.00', 40),
(3, 10, '30000.00', 20),
(4, 25, '90000.00', 50),
(5, 18, '60000.00', 35),
(6, 12, '35000.00', 25),
(7, 22, '80000.00', 45),
(8, 28, '100000.00', 60),
(9, 14, '45000.00', 30),
(10, 16, '55000.00', 32);

--
-- Indeksy dla zrzutów tabel
--

--
-- Indeksy dla tabeli `backupiodtwarzanieawaryjne`
--
ALTER TABLE `backupiodtwarzanieawaryjne`
  ADD PRIMARY KEY (`ID`);

--
-- Indeksy dla tabeli `danebagażu`
--
ALTER TABLE `danebagażu`
  ADD PRIMARY KEY (`ID`);

--
-- Indeksy dla tabeli `danebezpieczeństwa`
--
ALTER TABLE `danebezpieczeństwa`
  ADD PRIMARY KEY (`ID`);

--
-- Indeksy dla tabeli `danelotów`
--
ALTER TABLE `danelotów`
  ADD PRIMARY KEY (`ID`);

--
-- Indeksy dla tabeli `danepasażerów`
--
ALTER TABLE `danepasażerów`
  ADD PRIMARY KEY (`ID`);

--
-- Indeksy dla tabeli `danepersonelulotniska`
--
ALTER TABLE `danepersonelulotniska`
  ADD PRIMARY KEY (`ID`);

--
-- Indeksy dla tabeli `daneprzesyłekicargo`
--
ALTER TABLE `daneprzesyłekicargo`
  ADD PRIMARY KEY (`ID`);

--
-- Indeksy dla tabeli `danesamolotów`
--
ALTER TABLE `danesamolotów`
  ADD PRIMARY KEY (`ID`);

--
-- Indeksy dla tabeli `danestatystyczne`
--
ALTER TABLE `danestatystyczne`
  ADD PRIMARY KEY (`ID`);

--
-- Indeksy dla tabeli `historialotów`
--
ALTER TABLE `historialotów`
  ADD PRIMARY KEY (`ID`);

--
-- Indeksy dla tabeli `systembagażowy`
--
ALTER TABLE `systembagażowy`
  ADD PRIMARY KEY (`ID`);

--
-- Indeksy dla tabeli `systemkontrolilotów`
--
ALTER TABLE `systemkontrolilotów`
  ADD PRIMARY KEY (`ID`);

--
-- Indeksy dla tabeli `systemobsługiklienta`
--
ALTER TABLE `systemobsługiklienta`
  ADD PRIMARY KEY (`ID`);

--
-- Indeksy dla tabeli `systemrezerwacji`
--
ALTER TABLE `systemrezerwacji`
  ADD PRIMARY KEY (`ID`);

--
-- Indeksy dla tabeli `zabezpieczeniaiuprawnienia`
--
ALTER TABLE `zabezpieczeniaiuprawnienia`
  ADD PRIMARY KEY (`ID`);

--
-- Indeksy dla tabeli `zarezerwowanebilety`
--
ALTER TABLE `zarezerwowanebilety`
  ADD PRIMARY KEY (`ID`);

--
-- Indeksy dla tabeli `zarządzaniezasobami`
--
ALTER TABLE `zarządzaniezasobami`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT dla zrzuconych tabel
--

--
-- AUTO_INCREMENT dla tabeli `backupiodtwarzanieawaryjne`
--
ALTER TABLE `backupiodtwarzanieawaryjne`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT dla tabeli `danebagażu`
--
ALTER TABLE `danebagażu`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT dla tabeli `danebezpieczeństwa`
--
ALTER TABLE `danebezpieczeństwa`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT dla tabeli `danelotów`
--
ALTER TABLE `danelotów`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT dla tabeli `danepasażerów`
--
ALTER TABLE `danepasażerów`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT dla tabeli `danepersonelulotniska`
--
ALTER TABLE `danepersonelulotniska`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT dla tabeli `daneprzesyłekicargo`
--
ALTER TABLE `daneprzesyłekicargo`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT dla tabeli `danesamolotów`
--
ALTER TABLE `danesamolotów`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT dla tabeli `danestatystyczne`
--
ALTER TABLE `danestatystyczne`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT dla tabeli `historialotów`
--
ALTER TABLE `historialotów`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT dla tabeli `systembagażowy`
--
ALTER TABLE `systembagażowy`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT dla tabeli `systemkontrolilotów`
--
ALTER TABLE `systemkontrolilotów`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT dla tabeli `systemobsługiklienta`
--
ALTER TABLE `systemobsługiklienta`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT dla tabeli `systemrezerwacji`
--
ALTER TABLE `systemrezerwacji`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT dla tabeli `zabezpieczeniaiuprawnienia`
--
ALTER TABLE `zabezpieczeniaiuprawnienia`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT dla tabeli `zarezerwowanebilety`
--
ALTER TABLE `zarezerwowanebilety`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT dla tabeli `zarządzaniezasobami`
--
ALTER TABLE `zarządzaniezasobami`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
